#ifndef LAUNCHERLIB_H
#define LAUNCHERLIB_H

#define DECL_EXPORT __attribute__ ((__visibility__("default")))

#endif
