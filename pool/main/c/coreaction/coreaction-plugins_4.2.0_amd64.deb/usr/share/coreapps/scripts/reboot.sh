#!/bin/bash
reboot
