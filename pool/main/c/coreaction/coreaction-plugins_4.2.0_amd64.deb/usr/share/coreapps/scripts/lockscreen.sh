#!/bin/bash
xdg-screensaver lock

