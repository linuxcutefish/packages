#!/bin/bash
xset dpms force on
