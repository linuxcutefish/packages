#!/bin/bash
systemctl hibernate
