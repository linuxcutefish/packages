#!/bin/bash
poweroff
