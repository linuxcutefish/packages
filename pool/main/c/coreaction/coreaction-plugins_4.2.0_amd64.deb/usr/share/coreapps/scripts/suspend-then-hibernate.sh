#!/bin/bash
systemctl suspend-then-hibernate 
