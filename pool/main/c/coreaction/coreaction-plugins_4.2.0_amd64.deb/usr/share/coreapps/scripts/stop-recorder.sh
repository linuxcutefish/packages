#!/bin/bash
#killall screenrecord-with-camera.sh &&
killall ffmpeg && killall ffplay 
killall wf-recorder
exit
