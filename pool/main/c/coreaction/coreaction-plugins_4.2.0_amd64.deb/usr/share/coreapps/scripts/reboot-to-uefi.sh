#!/bin/bash
systemctl reboot --firmware-setup
