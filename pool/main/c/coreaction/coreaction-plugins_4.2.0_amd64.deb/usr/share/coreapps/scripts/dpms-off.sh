#!/bin/bash
xset dpms force off
kscreen-doctor -d off
