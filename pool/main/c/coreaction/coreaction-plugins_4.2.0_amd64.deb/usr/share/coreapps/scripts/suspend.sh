#!/bin/bash
systemctl suspend
