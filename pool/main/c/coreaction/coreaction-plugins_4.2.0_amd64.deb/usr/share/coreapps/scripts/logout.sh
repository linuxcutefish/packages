#!/bin/bash

loginctl terminate-user $USER

#pkill -u $USER
